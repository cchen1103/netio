from .netio import main

"""
run as python module
"""
main()
